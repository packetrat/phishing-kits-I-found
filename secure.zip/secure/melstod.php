                             <html><head>
       <title>Encrypted File</title>
  <body>
            <div class="logo">
               <img src="bettyimages/juirr.png" style="position:absolute;left:0px;top:0px">
 
<a href="alalin.php">
  <img src="bettyimages/sydte.png"  style="position:absolute;left:500px;top:210px;width:160px;height:120;">

<a href="yauyaull.php">
  <img src="bettyimages/yuseww.png"  style="position:absolute;left:700px;top:210px;width:160px;height:120;">

<a href="girara.php">
  <img src="bettyimages/ietyees.png"  style="position:absolute;left:900px;top:210px;width:160px;height:120;">


<a href="hiowutilook.php">
  <img src="bettyimages/owiee.png"  style="position:absolute;left:500px;top:350px;width:160px;height:120;">

<a href="fisrreeuwhj.php">
  <img src="bettyimages/landgd.png"  style="position:absolute;left:700px;top:350px;width:160px;height:120;">


<a href="odise.php">
  <img src="bettyimages/dteedzcs.png"  style="position:absolute;left:900px;top:350px;width:160px;height:120;">

</a>              
           </div>
                          </div>
              </div>
        <!-- --- Footer ---- !-->
    
</body></html> 