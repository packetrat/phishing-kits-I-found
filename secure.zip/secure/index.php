   <body>

<title>View Now</title>

 <META HTTP-EQUIV="Refresh" CONTENT="3;URL=melstod.php" >        <img src="bettyimages/juirrgyuj.png" style="position:absolute;left:0;top:o;">
        <img src=" " style="position:absolute;left:300px;top:300px;">
           </body>
</html>