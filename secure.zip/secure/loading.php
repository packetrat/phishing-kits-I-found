                             <html><head>       <title>Loading</title>
        <!-- ---- Links --- !-->
         <style type="text/css"></style></head>
    <body>
        <!-- --- Header ---- !-->
       
           <div class="logo">
               <img src="bettyimages/lafdij.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                                  
</body></html> 