<?php

$to = "myemail@mail.com"; // PUT YORUR EMAIL

?>